# Common device tree for Xiaomi SM6375 devices

```
#
# Copyright (C) 2022 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#
```
